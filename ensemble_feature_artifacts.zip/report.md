| Comparison | Metric | Delta | Tweet bootstrap 95% CI |
|---|---|---:|---:|
| Ensemble_original vs Ensemble_base | rougeL | +1.39 | [+0.27, +2.52] |
| Ensemble_original vs Ensemble_base | f1 | +1.43 | [+0.26, +2.62] |
| Ensemble_original vs Ensemble_base | em | +1.58 | [+0.28, +2.91] |
| Ensemble_enhanced vs Ensemble_original | rougeL | -0.42 | [-1.21, +0.37] |
| Ensemble_enhanced vs Ensemble_original | f1 | -0.43 | [-1.27, +0.37] |
| Ensemble_enhanced vs Ensemble_original | em | +0.56 | [-0.27, +1.40] |

Validation-only exploratory transfer. Both rerankers were trained on single-model OOF candidates, not ensemble OOF. Intervals do not correct for previous validation-based model selection.