| Candidates | Mean count | Top-1 RL | Oracle RL | Exact answer coverage |
|---|---:|---:|---:|---:|
| ProbabilityTop10 | 10.0 | 45.72 | 68.43 | 49.91% |
| ProbabilityTop30 | 30.0 | 45.72 | 73.22 | 55.95% |
| SeedTop10Union | 14.9 | 45.72 | 71.07 | 53.35% |