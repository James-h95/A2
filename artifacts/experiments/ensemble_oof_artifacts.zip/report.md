| Comparison | Metric | Delta | Tweet bootstrap 95% CI |
|---|---|---:|---:|
| OriginalOOF vs Ensemble_base | rougeL | +1.39 | [+0.27, +2.52] |
| OriginalOOF vs Ensemble_base | f1 | +1.43 | [+0.26, +2.62] |
| OriginalOOF vs Ensemble_base | em | +1.58 | [+0.28, +2.91] |
| MatchedEnsembleOOF vs OriginalOOF | rougeL | -0.61 | [-1.46, +0.22] |
| MatchedEnsembleOOF vs OriginalOOF | f1 | -0.57 | [-1.43, +0.29] |
| MatchedEnsembleOOF vs OriginalOOF | em | +0.00 | [-1.01, +0.95] |

Validation-only comparison of fixed single-model OOF training and matched ensemble OOF training. Intervals do not correct for previous validation-based model selection.